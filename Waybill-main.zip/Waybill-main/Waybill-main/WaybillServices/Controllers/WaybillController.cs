﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DonationsServices.Data;
using DonationsServices.Models;

namespace DonationsServices.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DonationsController : Controller
    {
        private readonly CityHopeContext _context;


        public DonationsController(CityHopeContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("get-donations")]
        public IActionResult GetDonations()
        {
            List<donations> donations = _context.donations.ToList();
            return (Ok(donations));
        }


        [HttpGet]
        [Route("get-donations/{Id}")]
        public IActionResult GetDonations(int Id)
        {
            donations donations = _context.donations.Where(p => p.donated == Id).FirstOrDefault();
            return (Ok(donations));
        }



        [HttpPost]
        [Route("create-donations")]
        public IActionResult Create(donations donations)
        {
            _context.Attach(donations);
            _context.Entry(donations).State = Microsoft.EntityFrameworkCore.EntityState.Added;
            _context.SaveChanges();

            return (Ok(true));

        }
    }
}
