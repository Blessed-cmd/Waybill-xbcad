﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DonationsServices.Models;

#nullable disable

namespace DonationsServices.Data
{
    public partial class CityHopeContext : DbContext
    {
        public CityHopeContext()
        {
        }

        public CityHopeContext(DbContextOptions<CityHopeContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Branch> Branches { get; set; }
        public virtual DbSet<Quantity> Quantities { get; set; }
        public virtual DbSet<donations> donations { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("(LocalDB)\\MSSQLLocalDB (DESKTOP-G5PJIGO\\bless);");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Branch>(entity =>
            {

                entity.Property(e => e.BranchName).IsUnicode(false);


                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.Branches)
                    .HasForeignKey(d => d.VehicleId);
                    

                entity.HasOne(d => d.Waybill)
                    .WithMany(p => p.Branches)
                    .HasForeignKey(d => d.WaybillId);
            });

            modelBuilder.Entity<Quantity>(entity =>
            {
                entity.Property(e => e.Units).IsUnicode(false);

                entity.Property(e => e.Items).IsUnicode(false);

            });

            modelBuilder.Entity<Waybill>(entity =>
            {
                entity.Property(e => e.ArrivalDate).IsUnicode(false);

                entity.Property(e => e.CurrentBranch).IsUnicode(false);

                entity.Property(e => e.DepartureDate).IsUnicode(false);

                entity.Property(e => e.Dimensions).IsUnicode(false);

                entity.Property(e => e.TotWeight).IsUnicode(false);

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.Waybills)
                    .HasForeignKey(d => d.VehicleId);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
