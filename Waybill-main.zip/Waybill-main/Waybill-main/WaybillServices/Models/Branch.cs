﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace DonationsServices.Models
{
    [Table("CityHope")]
    public partial class Branch
    {
        [Key]
        [Column("BranchID")]
        public int BranchId { get; set; }
        [StringLength(255)]
        public string BranchName { get; set; }
        [StringLength(255)]
    
        public int? WaybillId { get; set; }
        [Column("VehicleID")]
        public int? VehicleId { get; set; }

        public virtual Waybill Waybill { get; set; }
    }
}
