﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace DonationsServices.Models
{
    public partial class Quantity
    {
        public Quantity()
        {
            Branches = new HashSet<Branch>();
            Waybills = new HashSet<Waybill>();
        }

        [Key]
        [Column("QuantityID")]
        public int QuantityId { get; set; }
        [StringLength(255)]
        public string Items { get; set; }
        [StringLength(255)]
        public string VehicleModel { get; set; }
        [StringLength(255)]
        public string VehicleColor { get; set; }
        [StringLength(255)]
        public string Units { get; set; }

        //[InverseProperty(nameof(Branch.))]
        //public virtual ICollection<Branch> Branches { get; set; }
        //[InverseProperty(nameof(Waybill.Vehicle))]
        public virtual ICollection<Waybill> Waybills { get; set; }
    }
}
