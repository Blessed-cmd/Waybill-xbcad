﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace DonationsServices.Models
{
    [Table("Waybill")]
    public partial class Waybill
    {
        public Waybill()
        {
            Branches = new HashSet<Branch>();
        }

        [Key]
        [Column("WaybillID")]
        public int WaybillId { get; set; }
        [StringLength(255)]
       
        public int? DonationId { get; set; }
        [StringLength(255)]

        public int? DonationAmt { get; set; }

        public string TotWeight { get; set; }
        [StringLength(255)]
        public string Dimensions { get; set; }

        [ForeignKey(nameof(DonationId))]
        [InverseProperty("Waybills")]

        public virtual ICollection<Branch> Branches { get; set; }
    }
}
