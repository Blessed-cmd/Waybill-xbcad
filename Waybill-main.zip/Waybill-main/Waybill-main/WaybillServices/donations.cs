using System;

namespace DonationsServices
{
    public class donations
    {

        public DateTime itemName { get; set; }

        public int quantity { get; set; }

        public int donated { get; set; }

        public string value { get; set; }

        public string dateRecieved { get; set; }

        public string expiryDate { get; set; }

    }
}
